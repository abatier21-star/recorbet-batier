# RECORBET BATIER V2 — compilation depuis un téléphone

Ce projet est prévu pour être envoyé dans un dépôt GitHub. Le workflow `.github/workflows/build-apk.yml` compile automatiquement l'application sur les serveurs GitHub et dépose l'APK dans les **Artifacts** de l'exécution.

## Depuis le téléphone
1. Ouvrir GitHub dans Chrome et créer un dépôt vide.
2. Décompresser ce ZIP si nécessaire.
3. Ajouter tous les fichiers du dossier dans le dépôt, en conservant notamment `.github/workflows/build-apk.yml`.
4. Attendre la compilation automatique ou ouvrir **Actions** et lancer **Construire APK RECORBET BATIER** avec **Run workflow**.
5. Ouvrir l'exécution terminée → **Artifacts** → télécharger `RECORBET-BATIER-V2-APK`.
6. Décompresser l'Artifact puis ouvrir `app-debug.apk` sur le Samsung pour l'installer.

Le projet V2 actuel fournit l'interface de base : accueil, chantiers, stocks dépôt/camion avec seuils, documents et outils. Les fonctions avancées (vraie génération PDF, base de données, sauvegarde automatique, OCR Testo, analyse photo/IA, notifications de stock) devront être ajoutées dans les prochaines versions.
