package fr.recorbetbatier.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App() } }
}

@Composable fun App() {
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Accueil", "Chantiers", "Stocks", "Documents", "Outils")
    Scaffold(bottomBar = { NavigationBar { tabs.forEachIndexed { i, t -> NavigationBarItem(selected=i==tab,onClick={tab=i},icon={Text(listOf("⌂","🔧","📦","📄","🛠")[i])},label={Text(t)}) } } }) { p ->
        Column(Modifier.padding(p).padding(16.dp).fillMaxSize()) {
            Text("RECORBET BATIER", style=MaterialTheme.typography.headlineSmall)
            Text("PLOMBERIE & CHAUFFAGE", style=MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(16.dp))
            when(tab) { 0 -> Home(); 1 -> Chantiers(); 2 -> Stocks(); 3 -> Documents(); else -> Outils() }
        }
    }
}

@Composable fun Home(){ Text("Bonjour ! 👋",style=MaterialTheme.typography.headlineMedium); Spacer(Modifier.height(12.dp)); Text("Assistant chantier"); Spacer(Modifier.height(12.dp)); listOf("📷 Analyse Photo","🔥 Combustion / Testo","📄 Rapport / PDF","🧮 Calculs & conversions","❓ Aide technique").forEach{ ElevatedButton(onClick={},modifier=Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(it)} }; Spacer(Modifier.height(16.dp)); Text("Dernières interventions",style=MaterialTheme.typography.titleMedium); Text("• Recherche de fuite\n• Contrôle combustion\n• Rapport d’intervention") }
@Composable fun Chantiers(){ Text("Chantiers",style=MaterialTheme.typography.headlineMedium); Spacer(Modifier.height(12.dp)); listOf("Client – Dépannage chauffage","Client – Recherche de fuite","Client – Entretien chaudière").forEach{Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(it,Modifier.padding(16.dp))}} }
@Composable fun Stocks(){ Text("Stocks",style=MaterialTheme.typography.headlineMedium); Spacer(Modifier.height(12.dp)); Text("Dépôt"); Stock("Raccords cuivre",24,10); Stock("Joints",8,10); Text("Camion",Modifier.padding(top=12.dp)); Stock("Raccords cuivre",6,5); Stock("Joints",3,5); Text("⚠️ Les seuils bas sont signalés automatiquement.",Modifier.padding(top=12.dp)) }
@Composable fun Stock(n:String,q:Int,min:Int){ Text("$n : $q  (mini $min)"+if(q<=min)"  ⚠️" else "",Modifier.padding(6.dp)) }
@Composable fun Documents(){ Text("Documents professionnels",style=MaterialTheme.typography.headlineMedium); Spacer(Modifier.height(12.dp)); listOf("Rapport d’intervention","Attestation recherche de fuite","Compte-rendu client","Fiche dépannage","Devis / Facture").forEach{ElevatedButton(onClick={},modifier=Modifier.fillMaxWidth().padding(vertical=4.dp)){Text("Créer $it")}} }
@Composable fun Outils(){ Text("Outils chantier",style=MaterialTheme.typography.headlineMedium); Spacer(Modifier.height(12.dp)); LazyColumn{items(listOf("Analyse photo","Analyse combustion Testo","Diagnostic panne","Recherche de fuite","Calculs & conversions","Base technique","Aide & conseils")){Text("• $it",Modifier.padding(12.dp))}} }
